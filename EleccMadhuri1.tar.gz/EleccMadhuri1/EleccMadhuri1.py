import webapp2
import json
import os
import jinja2
from google.appengine.ext import db
from itertools import groupby 
from collections import Counter
from collections import defaultdict
from jinja2 import Template

JINJA_ENVIRONMENT = jinja2.Environment(loader = jinja2.FileSystemLoader(os.path.dirname(__file__)),extensions=['jinja2.ext.autoescape'],autoescape=True)


class JsonProperty(db.TextProperty):
	def validate(self, value):
		return value

	def get_value_for_datastore(self, model_instance):
		result = super(JsonProperty, self).get_value_for_datastore(model_instance)
		result = json.dumps(result)
		return db.Text(result)

	def make_value_from_datastore(self, value):
		try:
			value = json.load(str(value))
		except:
			pass

		return super(JsonProperty, self).make_value_from_datastore(value)

def gql_json_parser(query_obj):
        result = []
        for entry in query_obj:
            result.append(dict([(p, unicode(getattr(entry, p))) for p in entry.properties()]))
        return result
class SA(db.Model):

	#SNO = db.IntegerProperty()
	Number = db.StringProperty()
	SenderServiceType = db.StringProperty()
	TotalNoOfSMS = db.IntegerProperty()
	NoofTxSMSs = db.IntegerProperty()
	NooPromotionalSMSs = db.IntegerProperty()
	obj = JsonProperty()


class MainPage(webapp2.RequestHandler):
    def get(self):
        template = JINJA_ENVIRONMENT.get_template('public/index.html')
    	path = os.getcwd()
    	abs_file_path = os.path.abspath('messages.json')
    	with open(abs_file_path) as obj:
    		my_obj = json.load(obj)

    		total_number_sms = Counter(service['number'] for service in my_obj['messages'])
    		total_number_sms = dict(total_number_sms)
    		total_number_text_sms = Counter(service['text'].encode('utf-8') for service in my_obj['messages'] if 'text' in service)
    		total_number_text_sms = dict(total_number_text_sms)
    		total_number_promo_sms = Counter(service['text'].encode('utf-8') for service in my_obj['messages'] if 'text' in service)
    		total_number_promo_sms = dict(total_number_promo_sms)
    		
    		filter_data_sms = dict((k,v) for k,v in total_number_sms.iteritems() if 'OLA' in k  or 'UBER' in k or 'HDFC' in k)
    		filter_data_text = dict((k,v) for k,v in total_number_text_sms.iteritems() if 'OTP' in k  or 'Uber' in k or 'bank' in k)
    		filter_data_promo = dict((k,v) for k,v in total_number_promo_sms.iteritems() if 'Use code' in k  or 'promo' in k or 'offer' in k)
    		

    		value=0
    		value2 = 0
    		new_dict = {}
    			

    		for x in filter_data_sms:
    			
    			if 'OLA' in x or 'UBER' in x:

    				value = value+filter_data_sms[x]
    				new_dict['OLA/UBER'] = value
 			
    			
    			elif 'HDFC' in x:
    				value2 = value2 + filter_data_sms[x]
    				new_dict['HDFC'] = value2
                #self.response.out.write(new_dict)
    		

    		
    		value3 = 0
    		value4 = 0
    		value5 = 0
    		new_dict1 = {}

    		for x in filter_data_text:
    			if 'OTP' in x or 'Uber' in x:
    				value3 = value3+filter_data_text[x]
    				new_dict1['OLA/UBER'] = value3
    			
    			elif 'bank' in x:
    				value5 = value5 + filter_data_text[x]
    				new_dict1['HDFC'] = value5
                #self.response.out.write(new_dict1)
    		

    		value6 = 0
    		value8 = 0
    		new_dict2 = {}

    		for x in filter_data_promo:
    			if 'Use code' in x or 'promo' in x:
    				value6 = value6+filter_data_promo[x]
    				new_dict2['OLA/UBER'] = value6
    			
    			elif 'offer' in x:
    				value8 = value8 + filter_data_promo[x]
    				new_dict2['HDFC'] = value8
    		#self.response.out.write(new_dict2)

    		superdict = dict((k, [new_dict.get(k),new_dict1.get(k), new_dict2.get(k)]) for k in set(new_dict.keys() + new_dict1.keys()+new_dict2.keys()))
    		#self.response.out.write(superdict)

    		for k,v in superdict.items():
    			
    			if 'OLA' in k:
    				service = 'CAB'
    				number = 'OLA'
    				value = v[0]
    				value1 = v[1]
    				value2 = v[2]
    			elif 'UBER' in k:
    				service = 'CAB'
    				number = 'UBER'
    				value = v[0]
    				value1 = v[1]
    				value2 = v[2]
    			elif 'HDFC' in k:
    				service = 'Bank'
    				number = 'HDFC'
    				value = v[0]
    				value1 = v[1]
    				value2 = v[2]
                #self.response.out.write(k)

    			entity = SA(SenderServiceType=service,Number=number,TotalNoOfSMS = value,NoofTxSMSs = value1,NooPromotionalSMSs = value2)
    			entity.put()
                                
                self.response.headers['Content-Type'] = 'text/html'
                self.response.write(template.render())
            
class Getentities(webapp2.RequestHandler):
    def get(self):
        template = JINJA_ENVIRONMENT.get_template('public/index.html')
        query_data = SA.all()
        json_query_data = gql_json_parser(query_data)
        json_query_data = json.dumps(json_query_data)
        self.response.headers['Content-Type'] = 'application/json'
        self.response.write(json_query_data)
    			
           	
application = webapp2.WSGIApplication([
    ('/', MainPage),
    ('/getdetails',Getentities),
    
], debug=True)


